import boto3
import csv
import urllib
import psycopg2

endpoint = 'kga-life.ccgci6xjexf4.ap-southeast-1.rds.amazonaws.com'
user = 'postgres'
password = 'Un!ted123'
db_name = 'kga-life'

connection = psycopg2.connect(user=user, password=password, host=endpoint, port="5432", database=db_name)

def lambda_handler(event, context):
    try:
        cursor = connection.cursor()

        bucket = event['Records'][0]['s3']['bucket']['name']
        file_key = urllib.parse.unquote_plus(event['Records'][0]['s3']['object']['key'], encoding='utf-8')
        s3 = boto3.client('s3')
        csvfile = s3.get_object(Bucket=bucket, Key=file_key)
        csvcontent = csvfile['Body'].read().decode('utf-8').splitlines()
        lines = csv.reader(csvcontent)
        headers = next(lines)

        for line in lines:
            try:
                insert_query = "INSERT INTO landing.member_list (type ,policy_number ,title ,first_name ,last_name ,id_number ,relation ,gender ,birth_date ,age ,date_captured ,inception_date ,waiting_period ,policy_code ,policy_description ,premium ,uw_premium ,cover ,under_writer ,status ,broker ,branch ,agent ,cell_number ,payment_type ,first_fiscal_period ,last_fiscal_period ,first_transaction_date ,last_transaction_date ,additional_products ,current_age ,pay_at_number ,work_permit ,premium_escalation_prcnt ,cover_escalation_prcnt ,beneficiary_full_name_1 ,beneficiary_id_number_1 ,beneficiary_relation_1 ,beneficiary_percentage_1 ,beneficiary_full_name_2 ,beneficiary_id_number_2 ,beneficiary_relation_2 ,beneficiary_percentage_2 ,beneficiary_full_name_3 ,beneficiary_id_number_3 ,beneficiary_relation_3 ,beneficiary_percentage_3 ,beneficiary_full_name_4 ,beneficiary_id_number_4 ,beneficiary_relation_4 ,beneficiary_percentage_4 ,beneficiary_full_name_5 ,beneficiary_id_number_5 ,beneficiary_relation_5 ,beneficiary_percentage_5 ) VALUES ('{0}' ,'{1}' ,'{2}' ,'{3}' ,'{4}' ,'{5}' ,'{6}' ,'{7}' ,'{8}' ,'{9}' ,'{10}' ,'{11}' ,'{12}' ,'{13}' ,'{14}' ,'{15}' ,'{16}' ,'{17}' ,'{18}' ,'{19}' ,'{20}' ,'{21}' ,'{22}' ,'{23}' ,'{24}' ,'{25}' ,'{26}' ,'{27}' ,'{28}' ,'{29}' ,'{30}' ,'{31}' ,'{32}' ,'{33}' ,'{34}' ,'{35}' ,'{36}' ,'{37}' ,'{38}' ,'{39}' ,'{40}' ,'{41}' ,'{42}' ,'{43}' ,'{44}' ,'{45}' ,'{46}' ,'{47}' ,'{48}' ,'{49}' ,'{50}' ,'{51}' ,'{52}' ,'{53}' ,'{54}')"
                cursor.execute(insert_query)
                connection.commit()
            except:
                continue

    except Exception as err:
        print(err)

